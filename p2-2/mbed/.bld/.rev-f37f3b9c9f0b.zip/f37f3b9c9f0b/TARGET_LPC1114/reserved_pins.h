// List of reserved pins for LPC1114

#ifndef RESERVED_PINS_H
#define RESERVED_PINS_H

#define TARGET_RESERVED_PINS {P0_0, P0_11, P1_0, P1_1, P1_2}

#endif
